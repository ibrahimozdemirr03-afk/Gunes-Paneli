package com.gunespaneli;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Güneş Paneli: evdeki telefonda çalışan paneli tam ekran gösteren uygulama.
 * Bağlantı Tailscale üzerinden kurulur; panel internete açılmaz.
 */
public class MainActivity extends Activity {

    private static final String ARKA_PLAN = "#0B1420";
    private static final long YENILEME_SURESI_MS = 15000;

    private WebView web;
    private SharedPreferences tercih;
    private long arkaPlanaGecis = 0;
    private boolean hataEkrani = false;

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        Window pencere = getWindow();
        pencere.setStatusBarColor(Color.parseColor(ARKA_PLAN));
        pencere.setNavigationBarColor(Color.parseColor("#131F2E"));

        tercih = getSharedPreferences("ayar", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor(ARKA_PLAN));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setUserAgentString(s.getUserAgentString() + " GunesPaneliApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest istek) {
                Uri u = istek.getUrl();
                if ("gunespaneli".equals(u.getScheme())) {
                    if ("ayar".equals(u.getHost())) {
                        adresSor(false);
                    } else {
                        yukle();
                    }
                    return true;
                }
                String sunucu = Uri.parse(adres()).getHost();
                if (sunucu != null && sunucu.equals(u.getHost())) {
                    return false;
                }
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest istek, WebResourceError hata) {
                if (istek.isForMainFrame()) {
                    hataGoster(String.valueOf(hata.getDescription()));
                }
            }
        });
        web.setDownloadListener((url, ua, aciklama, tur, uzunluk) -> indir(url, aciklama, tur));

        if (tercih.getString("adres", null) == null) {
            adresSor(true);
        } else {
            yukle();
        }
    }

    private String adres() {
        return tercih.getString("adres", "");
    }

    private void yukle() {
        hataEkrani = false;
        web.loadUrl(adres());
    }

    private void adresSor(boolean ilkKurulum) {
        EditText giris = new EditText(this);
        giris.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        giris.setSingleLine(true);
        String mevcut = tercih.getString("adres", "http://");
        giris.setText(mevcut);
        giris.setSelection(mevcut.length());
        int bosluk = (int) (20 * getResources().getDisplayMetrics().density);
        FrameLayout kutu = new FrameLayout(this);
        kutu.setPadding(bosluk, bosluk / 2, bosluk, 0);
        kutu.addView(giris);

        AlertDialog.Builder pencere = new AlertDialog.Builder(this)
                .setTitle("Sunucu adresi")
                .setMessage("Evdeki telefonun Tailscale adresi ve portu.\nÖrnek: http://100.101.102.103:8080")
                .setView(kutu)
                .setCancelable(!ilkKurulum)
                .setPositiveButton("Kaydet", (d, i) -> {
                    String a = giris.getText().toString().trim();
                    if (TextUtils.isEmpty(a) || "http://".equals(a)) {
                        adresSor(ilkKurulum);
                        return;
                    }
                    if (!a.startsWith("http://") && !a.startsWith("https://")) {
                        a = "http://" + a;
                    }
                    while (a.endsWith("/")) {
                        a = a.substring(0, a.length() - 1);
                    }
                    tercih.edit().putString("adres", a).apply();
                    yukle();
                });
        if (!ilkKurulum) {
            pencere.setNegativeButton("Vazgeç", null);
        }
        pencere.show();
    }

    private void hataGoster(String neden) {
        hataEkrani = true;
        String sayfa = "<!doctype html><html lang='tr'><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{margin:0;background:#0B1420;color:#EEF3F8;font:16px/1.5 system-ui,sans-serif;"
                + "display:flex;min-height:100vh;align-items:center;justify-content:center}"
                + ".k{max-width:340px;padding:28px}h1{font-size:1.3rem;margin:0 0 8px}"
                + "p{color:#93A3B5;margin:0 0 14px}ul{color:#93A3B5;padding-left:20px;margin:0 0 22px}"
                + "a{display:block;text-align:center;text-decoration:none;font-weight:700;padding:13px;"
                + "border-radius:12px;margin-bottom:10px}.a{background:#FFB421;color:#0B1420}"
                + ".b{background:#1A2A3C;color:#EEF3F8}small{color:#5A6878;word-break:break-all}</style></head>"
                + "<body><div class='k'><h1>Panele ulaşılamadı</h1>"
                + "<p>Evdeki telefona bağlanılamıyor. Şunları kontrol et:</p><ul>"
                + "<li>Bu telefonda Tailscale açık mı?</li>"
                + "<li>Evdeki telefon açık, Wi-Fi'a ve Tailscale'e bağlı mı?</li>"
                + "<li>Evdeki telefonda panel çalışıyor mu?</li></ul>"
                + "<a class='a' href='gunespaneli://yenile'>Tekrar dene</a>"
                + "<a class='b' href='gunespaneli://ayar'>Sunucu adresini değiştir</a>"
                + "<small>" + TextUtils.htmlEncode(adres()) + "<br>" + TextUtils.htmlEncode(neden) + "</small>"
                + "</div></body></html>";
        web.loadDataWithBaseURL(null, sayfa, "text/html", "utf-8", null);
    }

    private void indir(String url, String aciklama, String tur) {
        String ad = URLUtil.guessFileName(url, aciklama, tur);
        String cerez = CookieManager.getInstance().getCookie(url);
        Toast.makeText(this, "İndiriliyor: " + ad, Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String sonuc;
            try {
                HttpURLConnection baglanti = (HttpURLConnection) new URL(url).openConnection();
                if (cerez != null) {
                    baglanti.setRequestProperty("Cookie", cerez);
                }
                baglanti.setConnectTimeout(15000);
                baglanti.setReadTimeout(180000);
                ContentValues bilgi = new ContentValues();
                bilgi.put(MediaStore.Downloads.DISPLAY_NAME, ad);
                bilgi.put(MediaStore.Downloads.MIME_TYPE, tur);
                bilgi.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri hedef = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, bilgi);
                if (hedef == null) {
                    throw new IllegalStateException("İndirilenler klasörüne yazılamadı");
                }
                try (InputStream giris = baglanti.getInputStream();
                     OutputStream cikis = getContentResolver().openOutputStream(hedef)) {
                    if (cikis == null) {
                        throw new IllegalStateException("Dosya açılamadı");
                    }
                    byte[] tampon = new byte[16384];
                    int n;
                    while ((n = giris.read(tampon)) > 0) {
                        cikis.write(tampon, 0, n);
                    }
                }
                sonuc = ad + " İndirilenler klasörüne kaydedildi";
            } catch (Exception e) {
                sonuc = "İndirilemedi: " + e.getMessage();
            }
            final String mesaj = sonuc;
            new Handler(Looper.getMainLooper()).post(
                    () -> Toast.makeText(MainActivity.this, mesaj, Toast.LENGTH_LONG).show());
        }).start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        arkaPlanaGecis = System.currentTimeMillis();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (tercih.getString("adres", null) == null) {
            return;
        }
        if (hataEkrani) {
            yukle();
        } else if (arkaPlanaGecis > 0 && System.currentTimeMillis() - arkaPlanaGecis > YENILEME_SURESI_MS) {
            web.reload();
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack() && !hataEkrani) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
